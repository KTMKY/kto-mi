export default {
  name: "page",
  headerText: {
    type: "header",
    children: [
      {
        type: "line",
        children: [
          {
            type: "text",
            value: "PAGE #:",
            children: [],
          },
          {
            type: "space",
            length: 0.5,
            children: [],
          },
          {
            type: "underline",
            length: 4,
            children: [],
          },
        ],
      },
    ],
  },
};
