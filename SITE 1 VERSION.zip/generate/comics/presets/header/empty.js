export default {
  name: "empty",
  headerText: {
    type: "header",
    children: [],
  },
};
