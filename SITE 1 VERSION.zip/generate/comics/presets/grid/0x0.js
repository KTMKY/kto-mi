export default {
  name: "no panels",
  presetFormatVersion: "1.0.0",
  panelGrid: {
    id: "a59bd834-5743-4552-9843-239b0f88f325",
    type: "vgroup",
    sizePercentage: 100,
    children: [],
  },
};
