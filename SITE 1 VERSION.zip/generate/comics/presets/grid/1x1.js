export default {
  name: "1x1",
  presetFormatVersion: "1.0.0",
  panelGrid: {
    type: "vgroup",
    sizePercentage: 100,
    children: [
      {
        type: "hgroup",
        sizePercentage: 100,
        children: [
          {
            type: "panel",
            sizePercentage: 100,
            children: [],
          },
        ],
      },
    ],
  },
};
