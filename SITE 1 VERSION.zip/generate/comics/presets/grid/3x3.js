export default {
  name: "3x3",
  presetFormatVersion: "1.0.0",
  panelGrid: {
    type: "vgroup",
    sizePercentage: 100,
    children: [
      {
        type: "hgroup",
        sizePercentage: 33.333333333333336,
        children: [
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
        ],
      },
      {
        type: "hgroup",
        sizePercentage: 33.333333333333336,
        children: [
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
        ],
      },
      {
        type: "hgroup",
        sizePercentage: 33.333333333333336,
        children: [
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
          {
            type: "panel",
            sizePercentage: 33.333333333333336,
            children: [],
          },
        ],
      },
    ],
  },
};
